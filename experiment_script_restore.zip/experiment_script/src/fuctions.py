import os
import shutil

import constants


# =====================================================================================================
# Operation Function Definitions
# =====================================================================================================
def show_config(exp_config):
    print("Config: ", str(exp_config))


def update_exp_control(exp_config, new_sbfl=None, new_ranking=None, new_max_test=None, icj_black=None, d4j_path=None,
                       used_jar=None):
    if new_sbfl:
        exp_config.SbflAlgorithm = new_sbfl
    if new_ranking:
        exp_config.RankingAlgorithm = new_ranking
    if new_max_test:
        exp_config.MaxTestNumber = new_max_test
    if icj_black:
        exp_config.IcjBlackBoxOnly = icj_black.lower() in ("yes", "true", "t", "1")
    if d4j_path:
        exp_config.d4j_exe = d4j_path
    if used_jar:
        exp_config.used_jar = used_jar
    exp_config.write_config_file()


def clear_output(working_dir):
    for x_repo in os.listdir(working_dir):
        x_repo_dir = os.path.join(working_dir, x_repo)
        if os.path.isdir(x_repo_dir):
            for dirname, dirnames, filenames in os.walk(x_repo_dir):
                # print path to all subdirectories first.
                for subdirname in dirnames:
                    if subdirname == constants.OUTPUT_FOLDER_NAME:  # find the experiment output in repo
                        jaid_output_dir = os.path.join(dirname, subdirname)
                        # print(jaid_output_dir)
                        shutil.rmtree(jaid_output_dir)
                        # return


def print_available_bv():
    # print('Available D4J repositories name and corresponding identifier:')
    # print(constants.repositories)
    print('All available project and buggy ids:')
    print('<REPO_NAME>: <BUG_VERSION_1>,<BUG_VERSION2>,...')
    for project in constants.valid_bvs.keys():
        print(project + ' : ' + ','.join(sorted(set(constants.valid_bvs[project]))))
        print('\n')
    print('=' * 10)
    print('Defects4J <BUG_ID> format:' + constants.D4J_BUGID_FORMAT + ' (e.g.,Lang33)')
    print('IntroClassJava <BUG_ID> format:' + constants.ICJ_BUGID_FORMAT + ' (e.g.,checksum-e23b9_005)')
    print('QuixBugs <BUG_ID> format:' + constants.QB_BUGID_FORMAT + ' (e.g.,QB_SHORTEST_PATHS)')
    print('=' * 10)
    print('Example for running JAID to fix a buggy program:')
    print(
        '$ python3 <PATH_TO_jaid_exp_pre>/src/main.py ' + constants.COMMAND_RUN + ' Lang33,checksum-e23b9_005,QB_SHORTEST_PATHS')
    # print('All available IntroClassJava repositories:')
    # print(','.join(constants.ICJ_CANDIDATES.keys()))
    # print('Example for reading JAID\'s output of fixing a buggy program:')
    # print('$ python3 <PATH_TO_jaid_exp_pre>/src/main.py ' + constants.COMMAND_READ + ' Lang33,checksum-e23b9_005')
