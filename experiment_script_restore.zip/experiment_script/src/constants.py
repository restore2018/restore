PROPERTIES_FILE_NAME = 'setting.properties'
REQUIREMENT_FILE_NAME = 'requirements.txt'
ICJ_RESULT_FILE_NAME = 'icj_result.csv'
FIX_RANKING_SCORE_FILE_NAME = 'fix_ranking_score.csv'
ANALYSIS_TMP = 'analysis_tmp.txt'
PLAUSIBLE_FIX_ACTIONS_LOG = 'plausible_fix_actions.log'
MAIN_LOG = 'jaid.log'
ZIP_SUFFIX = '.zip'
JAID_ARG_PROPERTY = '--JaidSettingFile'
# JAID_ARG_PROPERTY = '--FixjaSettingFile'
OUTPUT_FOLDER_NAME = 'jaid_output'
ARGS_FORMAT = '<BUG_ID1,BUG_ID2,...>'
D4J_BUGID_FORMAT = '<REPO_NAME><DEFECTS4J_VERSION_ID>'
ICJ_BUGID_FORMAT = '<REPO_NAME>-<AUTHOR_ID>_<VERSION_ID>'
QB_PREFIX = 'QB_'
QB_BUGID_FORMAT = QB_PREFIX + '<CLASS_NAME>'
BACKUP_FOLDER_NAME = 'backup_'
JAVA_SUFFIX = ".java"

repositories = {'closure': 'closure-compiler',
                'lang': 'commons-lang',
                'math': 'commons-math',
                'time': 'joda-time',
                'chart': 'JFreechart',
                'mockito': 'mockito'}

valid_bvs = {
    'closure': ['all'],
    'lang': ['all'],
    'math': ['all'],
    'time': ['all'],
    'chart': ['all'],
    'mockito': ['all'],
    'checksum': ['659a7_003', '2c155_003', '36d80_003', 'a0e3f_005', 'a0e3f_000', 'e23b9_005', 'e9c74_000', '08c7e_010',
                 '08c7e_007', '08c7e_011', '08c7e_006'],
    'digits': ['d6364_000', '48b82_000', '313d5_000', '6e464_003', '6e464_004', '6e464_000', 'd8b26_000', '295af_003',
               '295af_000', '295af_002', 'f2997_000', 'f2997_002', 'c9d71_001', 'c9d71_000', '98d87_003', '98d87_001',
               '98d87_004', '98d87_000', 'ca505_003', 'f227e_000', 'ca94e_000', 'ca94e_002', 'a0e3f_003', '1b31f_000',
               '1b31f_002', '0cea4_000', '0cea4_002', '317aa_004', '317aa_002', 'cd2d9_003', '5b504_000', 'c5d8f_003',
               'e9c74_000', 'd43d3_000', '833bd_000', '387be_000', '387be_002', 'd1204_001', 'd1204_000', '1c2bb_003',
               '1c2bb_000', 'd767a_007', '65e02_015', '65e02_004', 'bfad6_003', 'bfad6_005', 'bfad6_004', 'bfad6_000',
               '08c7e_001', '08c7e_000', '3214e_003', '3214e_000', '90a14_004', '90a14_000', '1391c_000', '1391c_002',
               'd2b88_003', 'd2b88_001', 'd2b88_005', 'd2b88_004', 'd2b88_006', 'd2b88_000', '0cdfa_007', '0cdfa_005',
               '0cdfa_004', '0cdfa_006', '88394_003', '88394_004', 'e79f8_000', 'e79f8_002', '07045_000', '07045_002',
               'd5059_000', '2af3c_000', '9013b_001'],
    'grade': ['b1924_003', 'b1924_001', 'b1924_000', 'd6364_007', '48b82_000', 'dccb1_001', '6e464_000', 'd8b26_000',
              '769cd_000', '295af_010', 'aacea_003', 'af81f_009', 'af81f_001', 'af81f_007', 'af81f_000', 'af81f_002',
              'f5b56_010', 'f5b56_000', 'ee1f2_000', 'c9d71_003', 'c9d71_001', 'c9d71_004', 'c9d71_000', 'c9d71_002',
              '98d87_004', '68ea5_000', '36d80_000', 'ca94e_000', 'a0e3f_010', 'a0e3f_012', '1b31f_003', '3cf6d_010',
              '0cea4_003', '0cea4_001', '0cea4_000', '0cea4_002', 'e23b9_003', 'e23b9_001', 'e23b9_004', 'e23b9_000',
              'e23b9_002', '317aa_003', '317aa_001', '317aa_004', '317aa_000', 'cd2d9_008', 'cd2d9_009', 'cd2d9_003',
              'cd2d9_010', 'cd2d9_007', 'cd2d9_013', 'cd2d9_006', '5b504_000', '48925_010', '48925_000', '9c930_003',
              '9c930_007', '9c930_000', '833bd_003', '387be_000', '92b7d_002', '1c2bb_003', '1c2bb_000', '95362_014',
              '95362_015', '95362_010', '95362_013', '95362_018', 'fe9d5_003', 'fe9d5_004', 'bfad6_001', 'bfad6_000',
              '93f87_015', '30074_004', 'dc11f_000', '89b1a_003', '0cdfa_003', '90834_009', '90834_010', '90834_013',
              '3b237_007', 'd009a_003', 'd009a_000', 'cb243_001', 'cb243_000', 'b6fd4_000', '07045_002', '9013b_000',
              '75c98_003'],
    'median': ['48b82_000', '6e464_003', '2c155_000', 'aacea_003', 'af81f_007', 'af81f_004', '36d80_000', '6aaea_000',
               '1b31f_000', '3cf6d_007', '0cea4_003', '1bf73_003', '1bf73_000', '317aa_003', '317aa_000', '317aa_002',
               'cd2d9_010', '15cb0_003', '9c930_003', '9c930_007', '9c930_012', 'e9c62_001', 'e9c62_000', 'd43d3_000',
               'd1204_000', '1c2bb_000', '95362_003', '95362_000', 'fe9d5_000', 'fe9d5_002', '93f87_015', '93f87_010',
               '93f87_012', 'c716e_001', 'c716e_000', 'c716e_002', '30074_000', '89b1a_003', '89b1a_010', '89b1a_007',
               '90a14_000', 'd2b88_000', '0cdfa_003', 'd4aae_000', '68eb0_000', '90834_003', '90834_015', '90834_010',
               '3b237_003', '3b237_006', 'd009a_000', 'fcf70_003', 'fcf70_000', 'fcf70_002', 'b6fd4_001', 'b6fd4_000',
               '9013b_000'],
    'smallest': ['48b82_001', '48b82_000', '769cd_009', '769cd_003', '769cd_010', '769cd_007', '769cd_004', '769cd_002',
                 'af81f_000', 'f2997_000', 'c9d71_003', 'c9d71_000', '97f6b_003', '36d80_003', '6aaea_001', '6aaea_000',
                 '1b31f_003', '3cf6d_003', 'f8d57_000', '15cb0_007', 'e9c62_000', '2694a_000', '95362_009', '818f8_003',
                 '818f8_002', '93f87_000', 'c868b_000', '30074_007', '30074_000', 'ea67b_003', '90a14_001', '90a14_000',
                 '5a568_000', '68eb0_000', '88394_003', '88394_007', '88394_006', '88394_002', '90834_005', '3b237_008',
                 '3b237_003', '3b237_007', '3b237_006', '84602_007', 'd009a_001', 'cb243_000', 'dedc2_000', '346b1_003',
                 '346b1_010', '346b1_005', '346b1_002', '9013b_000'],
    'syllables': ['99cbb_003', 'ca505_003', '36d80_003', 'f8d57_002', '48925_007', '818f8_007', '38eb9_003',
                  '38eb9_004', '90a14_000', 'fcf70_002', 'b6fd4_000', 'd5059_000', '2af3c_003'],
    'QB': ['REVERSE_LINKED_LIST', 'TOPOLOGICAL_ORDERING', 'POSSIBLE_CHANGE', 'DEPTH_FIRST_SEARCH', 'KNAPSACK', 'PASCAL',
           'MAX_SUBLIST_SUM', 'HANOI', 'NEXT_PALINDROME', 'FIND_IN_SORTED', 'QUICKSORT', 'IS_VALID_PARENTHESIZATION',
           'SIEVE', 'SQRT', 'LIS', 'FIND_FIRST_IN_SORTED', 'RPN_EVAL', 'GCD', 'DETECT_CYCLE', 'KTH',
           'MINIMUM_SPANNING_TREE', 'FLATTEN', 'NEXT_PERMUTATION', 'BITCOUNT', 'TO_BASE', 'SUBSEQUENCES', 'LCS_LENGTH',
           'BREADTH_FIRST_SEARCH', 'LONGEST_COMMON_SUBSEQUENCE', 'MERGESORT', 'BUCKETSORT', 'SHUNTING_YARD',
           'SHORTEST_PATHS', 'LEVENSHTEIN', 'GET_FACTORS', 'WRAP', 'SHORTEST_PATH_LENGTH', 'SHORTEST_PATH_LENGTHS',
           'KHEAPSORT', 'POWERSET']}

COMMAND_SHOW_INFO = '--info'
COMMAND_SHOW_INFO_DESC = 'Display available projects and bug ids.'

COMMAND_SHOW_CONFIG = '--exp_config'
COMMAND_SHOW_CONFIG_DESC = 'Display the configuration file dir for experiment and its contents.'

COMMAND_SET_SBFL = '--sbfl'
COMMAND_SET_SBFL_DESC = 'Set SBFL algorithm'

COMMAND_SET_USED_JAR = '--used_jar'
COMMAND_SET_USED_JAR_DESC = 'Set used jar for experiment (the jar should locate in the `buggy_repo` folder)'

COMMAND_SET_RANKING = '--ranking'
COMMAND_SET_RANKING_DESC = 'Set ranking algorithm'

COMMAND_SET_D4J = '--d4j_path'
COMMAND_SET_D4J_DESC = 'Set executable Defect4J path'

COMMAND_SET_MAX_TEST = '--max_test'
COMMAND_SET_MAX_TEST_DESC = 'Set maximum number of involving passing test (-1 as no limitation)'

COMMAND_SET_ICJ_BLACK_TEST = '--icj_black'
COMMAND_SET_ICJ_BLACK_TEST_DESC = '(T/F) Whether using black-box test only on ICJ'

COMMAND_PREPARE = '--pre'
COMMAND_PREPARE_DESC = 'Prepare specific buggy version (property file)'

COMMAND_RUN = '--run'
COMMAND_RUN_DESC = 'Execute JAID against specific buggy program(s)'

COMMAND_CLEAR = '--clear'
COMMAND_CLEAR_DESC = 'Clear all repositories\' jaid_ouput under the buggy_repo folder'

Commands = {
    COMMAND_SHOW_INFO: COMMAND_SHOW_INFO_DESC,
    COMMAND_SHOW_CONFIG: COMMAND_SHOW_CONFIG_DESC,

    COMMAND_PREPARE: COMMAND_PREPARE_DESC,
    COMMAND_RUN: COMMAND_RUN_DESC,
    COMMAND_CLEAR: COMMAND_CLEAR_DESC,

    COMMAND_SET_USED_JAR: COMMAND_SET_USED_JAR_DESC,
    COMMAND_SET_SBFL: COMMAND_SET_SBFL_DESC,
    COMMAND_SET_RANKING: COMMAND_SET_RANKING_DESC,
    COMMAND_SET_MAX_TEST: COMMAND_SET_MAX_TEST_DESC,
    COMMAND_SET_ICJ_BLACK_TEST: COMMAND_SET_ICJ_BLACK_TEST_DESC,
    COMMAND_SET_D4J: COMMAND_SET_D4J_DESC,
}


ICJ_CANDIDATES = {
    'checksum': '0B3Jlt8l7iCKAZU5iekpSZ28wWW8',
    'digits': '0B3Jlt8l7iCKAZWU3MldaUmI5TW8',
    'grade': '0B3Jlt8l7iCKAdGFYdWdaMEo1OTA',
    'median': '0B3Jlt8l7iCKAMTk0aDFleXpJZEE',
    'smallest': '0B3Jlt8l7iCKAbVp5QURoZWVNWFU',
    'syllables': '0B3Jlt8l7iCKAdDRNcFQzUEhjREU',
}

QUIX_BUGS_GIT = 'https://github.com/chenliushan/QuixBugs.git'
QUIX_BUGS_REPO_NAME = 'QuixBugs'
QUIX_BUGS_BV_LIST = ['bitcount', 'breadth_first_search', 'bucketsort', 'depth_first_search', 'detect_cycle',
                     'find_first_in_sorted', 'find_in_sorted', 'flatten', 'gcd', 'get_factors', 'hanoi',
                     'is_valid_parenthesization', 'kheapsort', 'kth', 'lcs_length', 'levenshtein', 'lis',
                     'longest_common_subsequence', 'max_sublist_sum', 'mergesort', 'minimum_spanning_tree',
                     'next_palindrome', 'next_permutation', 'pascal', 'possible_change', 'powerset', 'quicksort',
                     'reverse_linked_list', 'rpn_eval', 'shortest_path_length', 'shortest_path_lengths',
                     'shortest_paths', 'shunting_yard', 'sieve', 'sqrt', 'subsequences', 'to_base',
                     'topological_ordering', 'knapsack', 'wrap']

JAID_JAR = "1yamvHTKlty_c3M0nNZikqNEawcRg_bre"
