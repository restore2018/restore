# JAID Experiment Script #
It could be time consuming for one who are not familiar with JAID and its experimental benchmarks (e.g., Defects4J, IntroClassJava and QuixBugs) to prepare the buggy program and a properties file for JAID. We have implement this automatic preparation script to help preparing both the buggy projects and property files. With this script, you can get everything ready by some commands.

### Environment requirement ###
* JDK8
* Python3 (with pip3)
* initialized Defects4J

### Getting start ###
1. Download the script project into a local directory $SCRIPT_DIR$.

2. Open a console window,  run the following command to see the helping message.
``` python3 $SCRIPT_DIR$/src/main.py -h ```

3. Input the JDK8 path when asked (skipped when when the path of JDK8 is found in thef system environment variable ``JAVA_HOME``).

4. Input the root path of Defects4J when asked.

### Common Usage Examples ###
* To prepare the a specified Defects4J (Lang33) and IntroClassJava (checksum-e23b9_005) buggy projects, you can execute following command.<br /> 
```$ python3 <PATH_TO_jaid_exp_pre>/src/main.py --pre Lang33,checksum-e23b9_005```<br />
Then the script mention above will checkout the buggy project version and generate a corresponding properties file for JAID automatically. After that it also prints the running argument (including the path of the properties file) that can be used to run JAID as follow.<br />
```--FixjaSettingFile <PATH_TO_jaid_exp_pre>/buggy_repo/commons-lang33/local_fixja.properties```

* To see all the available project buggy version.<br />
```$ python3 <PATH_TO_jaid_exp_pre>/src/main.py --info ```

* To run JAID to fix specified project(s) (preparation process will run automatically before executing JAID).<br />
```$ python3 <PATH_TO_jaid_exp_pre>/src/main.py --run Lang33,checksum-e23b9_005```
